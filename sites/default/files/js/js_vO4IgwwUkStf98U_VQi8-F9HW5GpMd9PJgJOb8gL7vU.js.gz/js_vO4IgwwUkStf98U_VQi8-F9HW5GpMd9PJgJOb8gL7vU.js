Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n>1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"Une erreur HTTP AJAX s\u0027est produite.","HTTP Result Code: !status":"Code de statut HTTP : !status","An AJAX HTTP request terminated abnormally.":"Une requ\u00eate HTTP AJAX s\u0027est termin\u00e9e anormalement.","Debugging information follows.":"Informations de d\u00e9bogage ci-dessous.","Path: !uri":"Chemin : !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText : !responseText","ReadyState: !readyState":"ReadyState : !readyState","Next":"Suivant","Disabled":"D\u00e9sactiv\u00e9","Enabled":"Activ\u00e9","Edit":"Modifier","Search":"Rechercher","Sunday":"Dimanche","Monday":"Lundi","Tuesday":"Mardi","Wednesday":"Mercredi","Thursday":"Jeudi","Friday":"Vendredi","Saturday":"Samedi","Add":"Ajouter","Upload":"Transf\u00e9rer","Configure":"Configurer","Done":"Termin\u00e9","OK":"OK","Prev":"Pr\u00e9c.","Mon":"lun","Tue":"mar","Wed":"mer","Thu":"jeu","Fri":"ven","Sat":"sam","Sun":"dim","January":"janvier","February":"F\u00e9vrier","March":"mars","April":"avril","May":"mai","June":"juin","July":"juillet","August":"ao\u00fbt","September":"septembre","October":"octobre","November":"novembre","December":"d\u00e9cembre","Show":"Afficher","Select all rows in this table":"S\u00e9lectionner toutes les lignes du tableau","Deselect all rows in this table":"D\u00e9s\u00e9lectionner toutes les lignes du tableau","Today":"Aujourd\u0027hui","Jan":"jan","Feb":"f\u00e9v","Mar":"mar","Apr":"avr","Jun":"juin","Jul":"juil","Aug":"ao\u00fb","Sep":"sep","Oct":"oct","Nov":"nov","Dec":"d\u00e9c","Su":"Di","Mo":"Lu","Tu":"Ma","We":"Me","Th":"Je","Fr":"Ve","Sa":"Sa","Not published":"Non publi\u00e9","Shortcuts":"Raccourcis","Please wait...":"Veuillez patienter...","Hide":"Masquer","mm\/dd\/yy":"dd\/mm\/yy","Only files with the following extensions are allowed: %files-allowed.":"Seuls les fichiers se terminant par les extensions suivantes sont autoris\u00e9s\u00a0: %files-allowed.","By @name on @date":"Par @name le @date","By @name":"Par @name","Not in menu":"Pas dans le menu","Alias: @alias":"Alias : @alias","No alias":"Aucun alias","New revision":"Nouvelle r\u00e9vision","Drag to re-order":"Cliquer-d\u00e9poser pour r\u00e9-organiser","Changes made in this table will not be saved until the form is submitted.":"Les changements effectu\u00e9s dans ce tableau ne seront pris en compte que lorsque la configuration aura \u00e9t\u00e9 enregistr\u00e9e.","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"N\u0027oubliez pas de cliquer sur \u003Cem\u003EEnregistrer les blocs\u003C\/em\u003E pour confirmer les modifications apport\u00e9es ici.","This permission is inherited from the authenticated user role.":"Ce droit est h\u00e9rit\u00e9e du r\u00f4le de l\u0027utilisateur authentifi\u00e9.","No revision":"Aucune r\u00e9vision","Requires a title":"Titre obligatoire","Not restricted":"Non restreint","(active tab)":"(onglet actif)","Not customizable":"Non personnalisable","Restricted to certain pages":"R\u00e9serv\u00e9 \u00e0 certaines pages","The block cannot be placed in this region.":"Le bloc ne peut pas \u00eatre plac\u00e9 dans cette r\u00e9gion.","Customize dashboard":"Personnaliser le tableau de bord","Hide summary":"Masquer le r\u00e9sum\u00e9","Edit summary":"Modifier le r\u00e9sum\u00e9","Don\u0027t display post information":"Ne pas afficher les informations de la contribution","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"Le fichier s\u00e9lectionn\u00e9 %filename ne peut pas \u00eatre transf\u00e9r\u00e9. Seulement les fichiers avec les extensions suivantes sont permis : %extensions.","Re-order rows by numerical weight instead of dragging.":"R\u00e9-ordonner les lignes avec des poids num\u00e9riques plut\u00f4t qu\u0027en les d\u00e9pla\u00e7ant.","Show row weights":"Afficher le poids des lignes","Hide row weights":"Cacher le poids des lignes","Autocomplete popup":"Popup d\u0027auto-compl\u00e9tion","Searching for matches...":"Recherche de correspondances...","Other":"Autre","Next page":"Page suivante","Previous page":"Page pr\u00e9c\u00e9dente","Previous image":"Image pr\u00e9c\u00e9dente","Next image":"Image suivante","Also allow !name role to !permission?":"Autoriser \u00e9galement le r\u00f4le !name \u00e0 !permission ?","Close":"Fermer","Loading...":"En cours de chargement...","Select":"S\u00e9lectionner","@count year from now":"@count ann\u00e9e \u00e0 partir de maintenant","@count years from now":"@count ann\u00e9es \u00e0 partir de maintenant","Submit":"Soumettre","Add file":"Ajouter un fichier","Log messages":"Journaliser les messages","Please select a file.":"Veuillez s\u00e9lectionner un fichier.","You are not allowed to operate on more than %num files.":"Vous n\u0027\u00eates pas autoris\u00e9(e) \u00e0 effectuer des op\u00e9rations sur plus de %num fichiers.","Please specify dimensions within the allowed range that is from 1x1 to @dimensions.":"Veuillez sp\u00e9cifier des dimensions dans la plage autoris\u00e9e, soit de 1x1 \u00e0 @dimensions.","%filename is not an image.":"%filename n\u0027est pas une image.","Do you want to refresh the current directory?":"Souhaitez-vous rafra\u00eechir le r\u00e9pertoire courant ?","Delete selected files?":"Voulez-vous vraiment supprimer les fichiers s\u00e9lectionn\u00e9s ?","Please select a thumbnail.":"Veuillez s\u00e9lectionner une vignette.","You must select at least %num files.":"Vous devez s\u00e9lectionner au moins %num fichier(s).","You can not perform this operation.":"Vous ne pouvez pas r\u00e9aliser cette op\u00e9ration.","Insert file":"Ins\u00e9rer un fichier","Change view":"Changer la vue","If you switch views, you will lose your selection.":"Si vous changez les vues, vous allez perdre votre s\u00e9lection.","Cannot continue, nothing selected":"Impossible de continuer, rien n\u0027est s\u00e9lectionn\u00e9","Error getting media.":"Erreur d\u0027obtention du m\u00e9dia.","There is nothing in your media library. Select the Upload tab above to add a file.":"Il n\u0027y a rien dans votre biblioth\u00e8que de m\u00e9dias. S\u00e9lectionnez l\u0027onglet Transf\u00e9rer ci-dessus pour ajouter un fichier.","Show layout designer":"Montrer l\u0027outil de mise en page","Hide layout designer":"Cacher l\u0027outil de mise en page","Automatic alias":"Alias automatique","Available tokens":"Jetons (tokens) disponibles","Insert this token into your form":"Ins\u00e9rer ce jeton (\u003Cem\u003Etoken\u003C\/em\u003E) dans votre formulaire","First click a text field to insert your tokens into.":"Cliquez d\u0027abord sur un champ de texte pour ins\u00e9rer vos jetons (\u003Cem\u003Etokens\u003C\/em\u003E) dans celui -ci.","Loading token browser...":"Chargement de l\u0027explorateur de jetons...","Remove group":"Supprimer le groupe","Apply (all displays)":"Appliquer (tous les affichages)","Apply (this display)":"Appliquer (cet affichage)","Revert to default":"R\u00e9tablir par d\u00e9faut"}} };;
/*
  @file
  Defines the simple modal behavior
*/
(function ($) {
  Drupal.behaviors.event_popup = {
    attach: function(context, settings) {
	  
	    if ($("#event-popup-container").length == 0) {
        // Add a container to the end of the body tag to hold the dialog
        $('body').append('<div id="event-popup-container" style="display:none;"></div>');
        try {
          // Attempt to invoke the simple dialog
          $( "#event-popup-container").dialog({
            autoOpen: false,
            modal: true,
            close: function(event, ui) {
              // Clear the dialog on close. Not necessary for your average use
              // case, butis useful if you had a video that was playing in the
              // dialog so that it clears when it closes
              $('#event-popup-container').html('');
            }
          });
          var defaultOptions = Drupal.event_popup.explodeOptions(settings.event_popup.defaults);
          $('#event-popup-container').dialog('option', defaultOptions);
        }
        catch (err) {
          // Catch any errors and report
          Drupal.event_popup.log('[error] Event Dialog: ' + err);
        }
	    }
	    // Add support for custom classes if necessary
      var classes = '';
      if (settings.event_popup.classes) {
        classes = ', .' + settings.event_popup.classes;
      }
	    $('a.event-popup' + classes, context).each(function(event) {
        if (!event.metaKey && !$(this).hasClass('simpleEventProcessed')) {
          // Add a class to show that this link has been processed already
          $(this).addClass('simpleEventProcessed');
          $(this).click(function(event) {
            // prevent the navigation
            event.preventDefault();
            // Set up some variables
            var url = $(this).attr('href');
            var title = $(this).attr('title');
            // Use defaults if not provided
            var selector = $(this).attr('name') ? 'event-calendar' : 'event_calendar';
            
            var options =  Drupal.event_popup.explodeOptions('width:auto;height:auto;position:[300,140]');
           
            if (url && title && selector) {
              // Set the custom options of the dialog
              $('#event-popup-container').dialog('option', options);
              
              // Set the title of the dialog
              $('#event-popup-container').dialog('option', 'title', title);
              
              // Add a little loader into the dialog while data is loaded
              $('#event-popup-container').html('<div class="event-popup-ajax-loader"></div>');
              
              // Change the height if it's set to auto
              if (options.height && options.height == 'auto') {
                $('#event-popup-container').dialog('option', 'height', 200);
              }
             
              // Use jQuery .get() to request the target page
              $.get(url, function(data) {
                // Re-apply the height if it's auto to accomodate the new content
                if (options.height && options.height == 'auto') {
					 
                  $('#event-popup-container').dialog('option', 'height', options.height);
                  
                }
                // Some trickery to make sure any inline javascript gets run.
                // Inline javascript gets removed/moved around when passed into
                // $() so you have to create a fake div and add the raw data into
                // it then find what you need and clone it. Fun.
                $('#event-popup-container').html( $( '<div></div>' ).html( data ).find( ':regex(class, .*'+selector+'.*)' ).not('.field').clone() );
                
                // Attach any behaviors to the loaded content
                //Drupal.attachBehaviors($('#event-popup-container'));
                
              });
              // Open the dialog
              $('#event-popup-container').dialog('open');
              // Return false for good measure
              return false;
            }
          });
        }
      });
	    var op = Drupal.settings.event_popup.op;
      if(op) {
        $('table.full tr td, table.mini tr td', context).click(function () {
	    //$('.fc-sun', context).click(function () {
			  var node_type = Drupal.settings.event_popup.content_type;
        node_type = node_type.replace('_', '-');
        var url = Drupal.settings.basePath + 'node/add/' +  node_type;
        var title =  'Create Event';
        // Use defaults if not provided
        var selector = Drupal.settings.event_popup.selector;
        //var options =  Drupal.event_popup.explodeOptions(settings.event_popup.defaults);
        var options =  Drupal.event_popup.explodeOptions('width:auto;height:auto;position:[300,140]');
        if (url && title && selector) {
			    var event_date = $(this).attr('data-date');
			    /* var event_date_sep = event_date.split('-');
			    var year = event_date_sep[0];
			    var month = event_date_sep[1];
			    var day = event_date_sep[2]; */
				  // Set the custom options of the dialog
          $('#event-popup-container').dialog('option', options);
          // Set the title of the dialog
          $('#event-popup-container').dialog('option', 'title', title);
          // Add a little loader into the dialog while data is loaded
          $('#event-popup-container').html('<div class="event-popup-ajax-loader"></div>');
          // Change the height if it's set to auto
          if (options.height && options.height == 'auto') {
            $('#event-popup-container').dialog('option', 'height', 200);
          }
          // Use jQuery .get() to request the target page
				
				$.get(url, {'date':event_date}, function(data) {
					
					 // Re-apply the height if it's auto to accomodate the new content
                if (options.height && options.height == 'auto') {
                  $('#event-popup-container').dialog('option', 'height', options.height);
                }
                // Some trickery to make sure any inline javascript gets run.
                // Inline javascript gets removed/moved around when passed into
                // $() so you have to create a fake div and add the raw data into
                // it then find what you need and clone it. Fun.
                $('#event-popup-container').html( $( '<div></div>' ).html( data ).find( '#' + selector ).clone() );
                // Attach any behaviors to the loaded content
                //Drupal.attachBehaviors($('#event-popup-container'));	 
				});
				 // Open the dialog
              $('#event-popup-container').dialog('open');
              // Return false for good measure
              return false;
			}
      });
      }
    }
		  
  };


// Create a namespace for our simple dialog module
  Drupal.event_popup = {};

  // Convert the options to an object
  Drupal.event_popup.explodeOptions = function (opts) {
    var options = opts.split(';');
    var explodedOptions = {};
    for (var i in options) {
      if (options[i]) {
        // Parse and Clean the option
        var option = Drupal.event_popup.cleanOption(options[i].split(':'));
        explodedOptions[option[0]] = option[1];
      }
    }
    return explodedOptions;
  }

  // Function to clean up the option.
  Drupal.event_popup.cleanOption = function(option) {
    // If it's a position option, we may need to parse an array
    if (option[0] == 'position' && option[1].match(/\[.*,.*\]/)) {
      option[1] = option[1].match(/\[(.*)\]/)[1].split(',');
      // Check if positions need be converted to int
      if (!isNaN(parseInt(option[1][0]))) {
        option[1][0] = parseInt(option[1][0]);
      }
      if (!isNaN(parseInt(option[1][1]))) {
        option[1][1] = parseInt(option[1][1]);
      }
    }
    // Convert text boolean representation to boolean
    if (option[1] === 'true') {
      option[1]= true;
    }
    else if (option[1] === 'false') {
      option[1] = false;
    }
    return option;
  }

  Drupal.event_popup.log = function(msg) {
    if (window.console) {
      window.console.log(msg);
    }

  }
  
})(jQuery);
;
/*
  @file
  Defines the simple modal behavior
*/
(function ($) {
  Drupal.behaviors.validates = {
    attach: function(context, settings) {
      var nodeType = Drupal.settings.event_popup.content_type;
      nodeType = nodeType.replace('_', '-');
      var formId = '#' + nodeType + '-node-form #edit-submit';
      $( formId ).click(function () {
      if ($("#display_error").length == 0) {
      $('#event-calendar-node-form').prepend('<div class="messages error" id = "display_error"><h2 class="element-invisible">Error message</h2><ul id="cl"  style="margin-left: 51px;"></ul></div>');
		   }
		  var eventTitle = $( '#edit-title'), 
		  startDate = $( '#edit-event-calendar-date-und-0-value-datepicker-popup-0' ),
		  endDate = $( '#edit-event-calendar-date-und-0-value2-datepicker-popup-0' ), 
		  showEndDate = $( '#edit-event-calendar-date-und-0-show-todate'),
		  allFields = $( [] ).add( eventTitle ).add( startDate ).add( endDate ),
		  tips = $( '#cl' );
		  var bValid = true;
		  allFields.removeClass( "ui-state-error" );
		  bValid = bValid && checkLength( eventTitle, "Event title", 1 );
                  bValid = bValid && checkStartDateLength( startDate, "Date", 1 );
                  if(showEndDate.attr('checked')) { 
                    bValid = bValid && checkEndDateLength( endDate, "Date", 1 );
		    bValid = bValid && DateCompare( startDate, endDate );
		  }
			if(!bValid) {
			  return false;
			}

      function updateTips( t ) {
	      tips
        .html( '<li>' + t + '</li>' )
        .addClass( "ui-state-highlight" );
        setTimeout(function() {
          tips.removeClass( "ui-state-highlight", 1500 );
        }, 500 );
      }
      function checkLength( o, n, min ) {
        if ( o.val().length < 1 ) {
          o.addClass( "ui-state-error" );
          updateTips( "Please enter event title");
            return false;
        } else {
          return true;
        }
      }

     function checkStartDateLength( o, n, min ) {
        if ( o.val().length < 1 ) {
          o.addClass( "ui-state-error" );
          updateTips( "Please enter start date");
            return false;
        } else {
          return true;
        }
      }
      
     function checkEndDateLength( o, n, min ) {
        if ( o.val().length < 1 ) {
          o.addClass( "ui-state-error" );
          updateTips( "Please enter end date");
            return false;
        } else {
          return true;
        }
      }
     
     function DateCompare(startDate, endDate) {
        var str1 = startDate.val();
        var str2 = endDate.val();
        if (str1.trim() != '' && str2.trim() != '') {
          var yr1 = parseInt(str1.substring(6, 10), 10);
          var dt1 = parseInt(str1.substring(3, 5), 10);
          var mon1 = parseInt(str1.substring(0, 2), 10);
          var yr2 = parseInt(str2.substring(6, 10), 10);
          var dt2 = parseInt(str2.substring(3, 5), 10);
          var mon2 = parseInt(str2.substring(0, 2), 10);
          var startDate1 = new Date(yr1, mon1, dt1);
          var endDate1 = new Date(yr2, mon2, dt2);
          if (startDate1 > endDate1) {
            startDate.addClass( "ui-state-error" );
            endDate.addClass( "ui-state-error" );
            updateTips( "Please enter valid date");
            return false;
        }
      }
        return true;
      }
	  });
    }
  };

})(jQuery);
;
